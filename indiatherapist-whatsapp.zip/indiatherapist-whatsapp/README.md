# 🧠 IndiaTherapist WhatsApp Automation Platform

AI-powered WhatsApp bot that automates client intake, therapist matching, session scheduling, and payment collection for IndiaTherapist.com.

## 🚀 Quick Start

### Step 1: Set Up Supabase Database

1. Go to [supabase.com](https://supabase.com) and create a free account
2. Create a new project (remember your database password)
3. Go to **SQL Editor** → **New Query**
4. Copy-paste the contents of `scripts/schema.sql` and click **Run**
5. Go to **Settings** → **API** and copy your:
   - Project URL (`SUPABASE_URL`)
   - `anon` public key (`SUPABASE_KEY`)
   - `service_role` secret key (`SUPABASE_SERVICE_KEY`)

### Step 2: Set Up WhatsApp Business API

1. Go to [developers.facebook.com](https://developers.facebook.com)
2. Create a new App → select **Business** type
3. Add the **WhatsApp** product
4. From WhatsApp → Getting Started, note your:
   - Phone Number ID (`WHATSAPP_PHONE_NUMBER_ID`)
   - Business Account ID (`WHATSAPP_BUSINESS_ACCOUNT_ID`)
5. From App Settings → Basic:
   - App ID
   - App Secret (`WHATSAPP_APP_SECRET`)
6. Generate a permanent access token (`WHATSAPP_ACCESS_TOKEN`)

### Step 3: Get Anthropic API Key

1. Go to [console.anthropic.com](https://console.anthropic.com)
2. Create an API key (`ANTHROPIC_API_KEY`)

### Step 4: Configure Environment

```bash
cp .env.example .env
# Edit .env with all your credentials
```

### Step 5: Seed Therapists

```bash
pip install -r requirements.txt
python scripts/seed_therapists.py
```

### Step 6: Run Locally

```bash
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

- API docs: http://localhost:8000/docs
- Admin dashboard: http://localhost:8000/admin
- Health check: http://localhost:8000/health

### Step 7: Deploy to Railway

1. Push this code to a GitHub repo
2. Go to [railway.app](https://railway.app) and create a new project
3. Connect your GitHub repo
4. Add all environment variables from `.env`
5. Railway auto-deploys on push

### Step 8: Configure WhatsApp Webhook

Once deployed, set your webhook URL in the Meta Developer Dashboard:

- **Webhook URL**: `https://your-app.up.railway.app/api/whatsapp/webhook`
- **Verify Token**: the value of `WHATSAPP_VERIFY_TOKEN` in your `.env`
- Subscribe to: `messages`

## 📁 Project Structure

```
├── app/
│   ├── main.py              # FastAPI entry point
│   ├── config/settings.py   # Environment config
│   ├── routes/
│   │   ├── webhook.py       # WhatsApp message handler
│   │   ├── admin.py         # Admin API endpoints
│   │   └── payments.py      # Payment webhooks
│   ├── services/
│   │   ├── whatsapp.py      # WhatsApp Cloud API client
│   │   ├── ai_agent.py      # Claude AI conversation brain
│   │   ├── database.py      # Supabase operations
│   │   ├── payment.py       # Razorpay/Stripe integration
│   │   └── scheduler.py     # Therapist notifications
│   ├── models/schemas.py    # Data models
│   └── templates/messages.py # Message templates
├── admin-dashboard/
│   └── index.html           # Full admin dashboard
├── scripts/
│   ├── schema.sql           # Database schema
│   └── seed_therapists.py   # Therapist data seeder
├── requirements.txt
├── Procfile                  # Railway deployment
└── .env.example              # Environment template
```

## 🔄 How It Works

1. Client clicks **Book Now** on IndiaTherapist.com → opens WhatsApp
2. WhatsApp sends the message to Meta's Cloud API
3. Meta forwards it to your server via webhook
4. AI agent (Claude) processes the message and generates a response
5. System collects client info, checks therapist availability, handles payment
6. Everything is logged in Supabase, viewable in the admin dashboard

## 🛡️ Admin Dashboard

Access at `https://your-app.up.railway.app/admin`

- **Dashboard**: Stats overview (clients, sessions, revenue)
- **Conversations**: Real-time chat monitoring with manual takeover
- **Therapists**: View and manage all therapists
- **Sessions**: Track all sessions and payments

## 💰 Estimated Monthly Costs

| Service | Cost |
|---------|------|
| WhatsApp Cloud API | $0 (1K free conversations) |
| Claude API | $15-30/month |
| Supabase | $0 (free tier) |
| Railway | $5-10/month |
| **Total** | **$20-40/month** |
