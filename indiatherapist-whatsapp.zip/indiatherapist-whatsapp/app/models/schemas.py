"""
Pydantic models for data validation across the application.
"""

from pydantic import BaseModel, EmailStr
from typing import Optional, Literal
from datetime import datetime
from enum import Enum


# ─── Enums ────────────────────────────────────────────────

class ClientStatus(str, Enum):
    NEW = "new"
    INTAKE = "intake"
    MATCHING = "matching"
    SCHEDULING = "scheduling"
    PAYMENT_PENDING = "payment_pending"
    ACTIVE = "active"
    INACTIVE = "inactive"


class SessionStatus(str, Enum):
    PENDING = "pending"
    CONFIRMED = "confirmed"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


class PaymentStatus(str, Enum):
    UNPAID = "unpaid"
    PAID = "paid"
    REFUNDED = "refunded"


class MessageDirection(str, Enum):
    INBOUND = "inbound"
    OUTBOUND = "outbound"


class TherapistTier(str, Enum):
    ELITE = "elite"
    PREMIUM = "premium"


# ─── Client Models ────────────────────────────────────────

class ClientCreate(BaseModel):
    phone: str
    name: Optional[str] = None
    email: Optional[str] = None
    country: Optional[str] = None
    preferred_language: Optional[str] = None
    concern: Optional[str] = None
    preferred_therapist: Optional[str] = None
    preferred_times: Optional[str] = None
    status: ClientStatus = ClientStatus.NEW


class ClientUpdate(BaseModel):
    name: Optional[str] = None
    email: Optional[str] = None
    country: Optional[str] = None
    preferred_language: Optional[str] = None
    concern: Optional[str] = None
    preferred_therapist: Optional[str] = None
    preferred_times: Optional[str] = None
    status: Optional[ClientStatus] = None


class Client(BaseModel):
    id: str
    phone: str
    name: Optional[str] = None
    email: Optional[str] = None
    country: Optional[str] = None
    preferred_language: Optional[str] = None
    concern: Optional[str] = None
    preferred_therapist: Optional[str] = None
    preferred_times: Optional[str] = None
    status: ClientStatus = ClientStatus.NEW
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


# ─── Therapist Models ─────────────────────────────────────

class Therapist(BaseModel):
    id: str
    name: str
    phone: Optional[str] = None
    email: Optional[str] = None
    specializations: list[str] = []
    languages: list[str] = []
    tier: TherapistTier = TherapistTier.PREMIUM
    session_price_usd: float = 0.0
    location: Optional[str] = None
    experience_years: Optional[int] = None
    is_active: bool = True
    created_at: Optional[str] = None


# ─── Session Models ───────────────────────────────────────

class SessionCreate(BaseModel):
    client_id: str
    therapist_id: str
    scheduled_at: Optional[str] = None
    amount_usd: float = 0.0


class Session(BaseModel):
    id: str
    client_id: str
    therapist_id: str
    scheduled_at: Optional[str] = None
    status: SessionStatus = SessionStatus.PENDING
    payment_status: PaymentStatus = PaymentStatus.UNPAID
    payment_id: Optional[str] = None
    amount_usd: float = 0.0
    created_at: Optional[str] = None


# ─── Conversation Models ──────────────────────────────────

class ConversationMessage(BaseModel):
    id: Optional[str] = None
    client_id: str
    direction: MessageDirection
    message: str
    stage: Optional[str] = None
    timestamp: Optional[str] = None


# ─── AI Agent Models ──────────────────────────────────────

class AgentAction(str, Enum):
    COLLECT_INFO = "COLLECT_INFO"
    CHECK_AVAILABILITY = "CHECK_AVAILABILITY"
    OFFER_ALTERNATIVES = "OFFER_ALTERNATIVES"
    SEND_PAYMENT_LINK = "SEND_PAYMENT_LINK"
    CONFIRM_SESSION = "CONFIRM_SESSION"
    ESCALATE_TO_HUMAN = "ESCALATE_TO_HUMAN"
    FOLLOW_UP = "FOLLOW_UP"
    GENERAL_RESPONSE = "GENERAL_RESPONSE"
    UPDATE_CLIENT_INFO = "UPDATE_CLIENT_INFO"


class AgentResponse(BaseModel):
    """What the AI agent returns after processing a message."""
    reply_message: str
    action: AgentAction = AgentAction.GENERAL_RESPONSE
    client_updates: Optional[dict] = None
    therapist_name: Optional[str] = None
    stage: str = "general"


# ─── WhatsApp Webhook Models ──────────────────────────────

class WhatsAppMessage(BaseModel):
    """Parsed incoming WhatsApp message."""
    from_number: str
    message_id: str
    message_text: str
    timestamp: str
    sender_name: Optional[str] = None


# ─── Admin API Models ─────────────────────────────────────

class AdminLogin(BaseModel):
    password: str


class TakeoverRequest(BaseModel):
    client_phone: str
    message: str


class ManualMessageRequest(BaseModel):
    client_phone: str
    message: str
