"""
Database service — all Supabase/PostgreSQL operations.
Handles clients, therapists, sessions, and conversation logging.
"""

import logging
from typing import Optional
from supabase import create_client, Client as SupabaseClient
from app.config.settings import get_settings

logger = logging.getLogger(__name__)

_supabase: Optional[SupabaseClient] = None


def get_db() -> SupabaseClient:
    """Get or create the Supabase client singleton."""
    global _supabase
    if _supabase is None:
        settings = get_settings()
        _supabase = create_client(settings.supabase_url, settings.supabase_service_key)
    return _supabase


# ─── Client Operations ────────────────────────────────────

async def get_client_by_phone(phone: str) -> Optional[dict]:
    """Look up a client by their WhatsApp phone number."""
    try:
        result = get_db().table("clients").select("*").eq("phone", phone).execute()
        if result.data and len(result.data) > 0:
            return result.data[0]
        return None
    except Exception as e:
        logger.error(f"Error fetching client by phone {phone}: {e}")
        return None


async def create_client(phone: str, data: dict = None) -> dict:
    """Create a new client record."""
    client_data = {"phone": phone, "status": "new"}
    if data:
        client_data.update(data)
    try:
        result = get_db().table("clients").insert(client_data).execute()
        return result.data[0] if result.data else client_data
    except Exception as e:
        logger.error(f"Error creating client: {e}")
        return client_data


async def update_client(phone: str, updates: dict) -> Optional[dict]:
    """Update a client's information."""
    try:
        # Remove None values
        updates = {k: v for k, v in updates.items() if v is not None}
        if not updates:
            return None
        result = get_db().table("clients").update(updates).eq("phone", phone).execute()
        return result.data[0] if result.data else None
    except Exception as e:
        logger.error(f"Error updating client {phone}: {e}")
        return None


async def get_all_clients() -> list:
    """Get all clients, ordered by most recent."""
    try:
        result = get_db().table("clients").select("*").order("created_at", desc=True).execute()
        return result.data or []
    except Exception as e:
        logger.error(f"Error fetching clients: {e}")
        return []


# ─── Therapist Operations ─────────────────────────────────

async def get_therapist_by_name(name: str) -> Optional[dict]:
    """Find a therapist by name (fuzzy match)."""
    try:
        result = get_db().table("therapists").select("*").ilike("name", f"%{name}%").execute()
        if result.data and len(result.data) > 0:
            return result.data[0]
        return None
    except Exception as e:
        logger.error(f"Error fetching therapist {name}: {e}")
        return None


async def get_therapist_by_id(therapist_id: str) -> Optional[dict]:
    """Get a therapist by ID."""
    try:
        result = get_db().table("therapists").select("*").eq("id", therapist_id).execute()
        return result.data[0] if result.data else None
    except Exception as e:
        logger.error(f"Error fetching therapist by ID: {e}")
        return None


async def get_all_therapists(active_only: bool = True) -> list:
    """Get all therapists."""
    try:
        query = get_db().table("therapists").select("*")
        if active_only:
            query = query.eq("is_active", True)
        result = query.order("tier").order("name").execute()
        return result.data or []
    except Exception as e:
        logger.error(f"Error fetching therapists: {e}")
        return []


async def get_alternative_therapists(exclude_name: str, languages: list = None) -> list:
    """Find alternative therapists when the requested one is unavailable."""
    try:
        query = get_db().table("therapists").select("*").eq("is_active", True).neq("name", exclude_name)
        result = query.execute()
        therapists = result.data or []
        # If language preference exists, sort matching ones first
        if languages:
            def lang_score(t):
                t_langs = t.get("languages", [])
                return sum(1 for l in languages if l in t_langs)
            therapists.sort(key=lang_score, reverse=True)
        return therapists[:5]
    except Exception as e:
        logger.error(f"Error fetching alternatives: {e}")
        return []


# ─── Session Operations ───────────────────────────────────

async def create_session(client_id: str, therapist_id: str, amount_usd: float) -> dict:
    """Create a new therapy session."""
    try:
        session_data = {
            "client_id": client_id,
            "therapist_id": therapist_id,
            "amount_usd": amount_usd,
            "status": "pending",
            "payment_status": "unpaid",
        }
        result = get_db().table("sessions").insert(session_data).execute()
        return result.data[0] if result.data else session_data
    except Exception as e:
        logger.error(f"Error creating session: {e}")
        return {}


async def update_session(session_id: str, updates: dict) -> Optional[dict]:
    """Update a session."""
    try:
        result = get_db().table("sessions").update(updates).eq("id", session_id).execute()
        return result.data[0] if result.data else None
    except Exception as e:
        logger.error(f"Error updating session: {e}")
        return None


async def get_sessions_by_client(client_id: str) -> list:
    """Get all sessions for a client."""
    try:
        result = (
            get_db()
            .table("sessions")
            .select("*, therapists(name, phone, email)")
            .eq("client_id", client_id)
            .order("created_at", desc=True)
            .execute()
        )
        return result.data or []
    except Exception as e:
        logger.error(f"Error fetching sessions: {e}")
        return []


async def get_all_sessions() -> list:
    """Get all sessions with client and therapist info."""
    try:
        result = (
            get_db()
            .table("sessions")
            .select("*, clients(name, phone, email), therapists(name, phone)")
            .order("created_at", desc=True)
            .execute()
        )
        return result.data or []
    except Exception as e:
        logger.error(f"Error fetching all sessions: {e}")
        return []


async def get_pending_payment_session(client_id: str) -> Optional[dict]:
    """Get the most recent session awaiting payment for a client."""
    try:
        result = (
            get_db()
            .table("sessions")
            .select("*, therapists(name, session_price_usd)")
            .eq("client_id", client_id)
            .eq("payment_status", "unpaid")
            .order("created_at", desc=True)
            .limit(1)
            .execute()
        )
        return result.data[0] if result.data else None
    except Exception as e:
        logger.error(f"Error fetching pending session: {e}")
        return None


# ─── Conversation Logging ─────────────────────────────────

async def log_message(client_id: str, direction: str, message: str, stage: str = None):
    """Log a conversation message."""
    try:
        msg_data = {
            "client_id": client_id,
            "direction": direction,
            "message": message,
            "stage": stage,
        }
        get_db().table("conversations").insert(msg_data).execute()
    except Exception as e:
        logger.error(f"Error logging message: {e}")


async def get_conversation_history(client_id: str, limit: int = 20) -> list:
    """Get recent conversation history for a client."""
    try:
        result = (
            get_db()
            .table("conversations")
            .select("*")
            .eq("client_id", client_id)
            .order("created_at", desc=True)
            .limit(limit)
            .execute()
        )
        messages = result.data or []
        messages.reverse()  # Chronological order
        return messages
    except Exception as e:
        logger.error(f"Error fetching conversation history: {e}")
        return []


async def get_all_conversations(limit: int = 100) -> list:
    """Get recent conversations across all clients."""
    try:
        result = (
            get_db()
            .table("conversations")
            .select("*, clients(name, phone)")
            .order("created_at", desc=True)
            .limit(limit)
            .execute()
        )
        return result.data or []
    except Exception as e:
        logger.error(f"Error fetching all conversations: {e}")
        return []


# ─── Human Takeover ───────────────────────────────────────

async def set_human_takeover(phone: str, active: bool = True) -> None:
    """Enable or disable human takeover for a client."""
    try:
        get_db().table("clients").update({"human_takeover": active}).eq("phone", phone).execute()
    except Exception as e:
        logger.error(f"Error setting takeover: {e}")


async def is_human_takeover(phone: str) -> bool:
    """Check if a client conversation is in human takeover mode."""
    client = await get_client_by_phone(phone)
    if client:
        return client.get("human_takeover", False)
    return False


# ─── Analytics ────────────────────────────────────────────

async def get_dashboard_stats() -> dict:
    """Get summary statistics for the admin dashboard."""
    try:
        db = get_db()
        clients = db.table("clients").select("id", count="exact").execute()
        active = db.table("clients").select("id", count="exact").eq("status", "active").execute()
        sessions = db.table("sessions").select("id", count="exact").execute()
        paid = db.table("sessions").select("amount_usd").eq("payment_status", "paid").execute()

        total_revenue = sum(s.get("amount_usd", 0) for s in (paid.data or []))

        return {
            "total_clients": clients.count or 0,
            "active_clients": active.count or 0,
            "total_sessions": sessions.count or 0,
            "total_revenue": total_revenue,
        }
    except Exception as e:
        logger.error(f"Error fetching stats: {e}")
        return {"total_clients": 0, "active_clients": 0, "total_sessions": 0, "total_revenue": 0}
