"""
Payment service — handles Razorpay and Stripe payment link generation
and webhook processing.
"""

import logging
from typing import Optional
from app.config.settings import get_settings

logger = logging.getLogger(__name__)


async def create_razorpay_payment_link(
    amount_usd: float,
    client_name: str,
    client_email: str,
    client_phone: str,
    session_id: str,
    therapist_name: str,
) -> Optional[str]:
    """
    Create a Razorpay payment link for a therapy session.
    Returns the payment link URL or None on failure.
    """
    settings = get_settings()
    if not settings.razorpay_key_id:
        logger.warning("Razorpay not configured, skipping payment link generation")
        return None

    try:
        import razorpay

        client = razorpay.Client(auth=(settings.razorpay_key_id, settings.razorpay_key_secret))

        # Razorpay uses paisa (1 USD = 100 cents, convert to INR if needed)
        # For international, use USD directly
        amount_cents = int(amount_usd * 100)

        link_data = {
            "amount": amount_cents,
            "currency": "USD",
            "accept_partial": False,
            "description": f"Therapy Session with {therapist_name} — India Therapist",
            "customer": {
                "name": client_name or "Client",
                "email": client_email or "",
                "contact": client_phone,
            },
            "notify": {"sms": False, "email": bool(client_email)},
            "reminder_enable": True,
            "notes": {
                "session_id": session_id,
                "therapist": therapist_name,
                "platform": "IndiaTherapist",
            },
            "callback_url": f"{settings.app_base_url}/api/payments/razorpay/callback",
            "callback_method": "get",
        }

        result = client.payment_link.create(link_data)
        payment_url = result.get("short_url")
        logger.info(f"Razorpay payment link created: {payment_url}")
        return payment_url

    except Exception as e:
        logger.error(f"Error creating Razorpay payment link: {e}")
        return None


async def create_stripe_payment_link(
    amount_usd: float,
    client_name: str,
    client_email: str,
    session_id: str,
    therapist_name: str,
) -> Optional[str]:
    """
    Create a Stripe checkout session for international payments.
    Returns the checkout URL or None on failure.
    """
    settings = get_settings()
    if not settings.stripe_secret_key:
        logger.warning("Stripe not configured, skipping payment link generation")
        return None

    try:
        import stripe

        stripe.api_key = settings.stripe_secret_key

        session = stripe.checkout.Session.create(
            payment_method_types=["card"],
            line_items=[
                {
                    "price_data": {
                        "currency": "usd",
                        "product_data": {
                            "name": f"Therapy Session — {therapist_name}",
                            "description": f"Online therapy session with {therapist_name} via India Therapist",
                        },
                        "unit_amount": int(amount_usd * 100),
                    },
                    "quantity": 1,
                }
            ],
            mode="payment",
            success_url=f"{settings.app_base_url}/api/payments/stripe/success?session_id={session_id}",
            cancel_url=f"{settings.app_base_url}/api/payments/stripe/cancel?session_id={session_id}",
            customer_email=client_email or None,
            metadata={
                "session_id": session_id,
                "therapist": therapist_name,
                "platform": "IndiaTherapist",
            },
        )

        logger.info(f"Stripe checkout created: {session.url}")
        return session.url

    except Exception as e:
        logger.error(f"Error creating Stripe checkout: {e}")
        return None


async def generate_payment_link(
    amount_usd: float,
    client_name: str,
    client_email: str,
    client_phone: str,
    session_id: str,
    therapist_name: str,
    prefer_razorpay: bool = False,
) -> Optional[str]:
    """
    Generate a payment link using the best available provider.
    Tries Stripe first (better for international NRI clients),
    falls back to Razorpay.
    """
    if prefer_razorpay:
        link = await create_razorpay_payment_link(
            amount_usd, client_name, client_email, client_phone, session_id, therapist_name
        )
        if link:
            return link

    # Try Stripe first for international clients
    link = await create_stripe_payment_link(
        amount_usd, client_name, client_email, session_id, therapist_name
    )
    if link:
        return link

    # Fallback to Razorpay
    link = await create_razorpay_payment_link(
        amount_usd, client_name, client_email, client_phone, session_id, therapist_name
    )
    return link
