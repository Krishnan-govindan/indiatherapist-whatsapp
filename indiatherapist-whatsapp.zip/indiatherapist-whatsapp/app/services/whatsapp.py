"""
WhatsApp Business Cloud API service.
Handles sending messages, parsing webhooks, and template management.
"""

import hmac
import hashlib
import logging
import httpx
from typing import Optional
from app.config.settings import get_settings

logger = logging.getLogger(__name__)

WHATSAPP_API_BASE = "https://graph.facebook.com/v21.0"


async def send_text_message(to_phone: str, message: str) -> bool:
    """
    Send a text message to a WhatsApp number.
    Args:
        to_phone: Recipient phone number (with country code, no +)
        message: Text message content
    Returns:
        True if sent successfully
    """
    settings = get_settings()
    url = f"{WHATSAPP_API_BASE}/{settings.whatsapp_phone_number_id}/messages"

    headers = {
        "Authorization": f"Bearer {settings.whatsapp_access_token}",
        "Content-Type": "application/json",
    }

    payload = {
        "messaging_product": "whatsapp",
        "recipient_type": "individual",
        "to": to_phone,
        "type": "text",
        "text": {"preview_url": False, "body": message},
    }

    try:
        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.post(url, json=payload, headers=headers)
            response.raise_for_status()
            data = response.json()
            logger.info(f"Message sent to {to_phone}: {data}")
            return True
    except httpx.HTTPStatusError as e:
        logger.error(f"WhatsApp API error sending to {to_phone}: {e.response.status_code} - {e.response.text}")
        return False
    except Exception as e:
        logger.error(f"Error sending WhatsApp message to {to_phone}: {e}")
        return False


async def send_interactive_buttons(to_phone: str, body_text: str, buttons: list[dict]) -> bool:
    """
    Send an interactive button message.
    Args:
        to_phone: Recipient phone number
        body_text: Message body
        buttons: List of {"id": "btn_id", "title": "Button Text"} (max 3)
    """
    settings = get_settings()
    url = f"{WHATSAPP_API_BASE}/{settings.whatsapp_phone_number_id}/messages"

    headers = {
        "Authorization": f"Bearer {settings.whatsapp_access_token}",
        "Content-Type": "application/json",
    }

    button_objects = [
        {"type": "reply", "reply": {"id": btn["id"], "title": btn["title"][:20]}}
        for btn in buttons[:3]
    ]

    payload = {
        "messaging_product": "whatsapp",
        "recipient_type": "individual",
        "to": to_phone,
        "type": "interactive",
        "interactive": {
            "type": "button",
            "body": {"text": body_text},
            "action": {"buttons": button_objects},
        },
    }

    try:
        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.post(url, json=payload, headers=headers)
            response.raise_for_status()
            return True
    except Exception as e:
        logger.error(f"Error sending interactive message to {to_phone}: {e}")
        return False


async def send_template_message(to_phone: str, template_name: str, language_code: str = "en_US", components: list = None) -> bool:
    """
    Send a pre-approved WhatsApp template message.
    Used for business-initiated conversations (outside 24hr window).
    """
    settings = get_settings()
    url = f"{WHATSAPP_API_BASE}/{settings.whatsapp_phone_number_id}/messages"

    headers = {
        "Authorization": f"Bearer {settings.whatsapp_access_token}",
        "Content-Type": "application/json",
    }

    template = {
        "name": template_name,
        "language": {"code": language_code},
    }
    if components:
        template["components"] = components

    payload = {
        "messaging_product": "whatsapp",
        "to": to_phone,
        "type": "template",
        "template": template,
    }

    try:
        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.post(url, json=payload, headers=headers)
            response.raise_for_status()
            logger.info(f"Template '{template_name}' sent to {to_phone}")
            return True
    except Exception as e:
        logger.error(f"Error sending template to {to_phone}: {e}")
        return False


async def mark_message_read(message_id: str) -> bool:
    """Mark a message as read (blue ticks)."""
    settings = get_settings()
    url = f"{WHATSAPP_API_BASE}/{settings.whatsapp_phone_number_id}/messages"

    headers = {
        "Authorization": f"Bearer {settings.whatsapp_access_token}",
        "Content-Type": "application/json",
    }

    payload = {
        "messaging_product": "whatsapp",
        "status": "read",
        "message_id": message_id,
    }

    try:
        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.post(url, json=payload, headers=headers)
            return response.status_code == 200
    except Exception:
        return False


def parse_webhook_message(body: dict) -> Optional[dict]:
    """
    Parse an incoming WhatsApp webhook payload and extract the message.
    Returns dict with: from_number, message_id, message_text, timestamp, sender_name
    """
    try:
        entry = body.get("entry", [])
        if not entry:
            return None

        changes = entry[0].get("changes", [])
        if not changes:
            return None

        value = changes[0].get("value", {})
        messages = value.get("messages", [])
        if not messages:
            return None

        msg = messages[0]
        contacts = value.get("contacts", [])
        sender_name = contacts[0].get("profile", {}).get("name", "") if contacts else ""

        # Handle text messages
        if msg.get("type") == "text":
            return {
                "from_number": msg["from"],
                "message_id": msg["id"],
                "message_text": msg["text"]["body"],
                "timestamp": msg.get("timestamp", ""),
                "sender_name": sender_name,
            }

        # Handle interactive button replies
        if msg.get("type") == "interactive":
            interactive = msg.get("interactive", {})
            if interactive.get("type") == "button_reply":
                return {
                    "from_number": msg["from"],
                    "message_id": msg["id"],
                    "message_text": interactive["button_reply"]["title"],
                    "timestamp": msg.get("timestamp", ""),
                    "sender_name": sender_name,
                }

        logger.info(f"Unsupported message type: {msg.get('type')}")
        return None

    except (KeyError, IndexError) as e:
        logger.error(f"Error parsing webhook: {e}")
        return None


def verify_webhook_signature(payload: bytes, signature: str) -> bool:
    """Verify that the webhook payload is genuinely from Meta."""
    settings = get_settings()
    if not settings.whatsapp_app_secret:
        logger.warning("No app secret configured, skipping signature verification")
        return True

    expected = hmac.new(
        settings.whatsapp_app_secret.encode(),
        payload,
        hashlib.sha256,
    ).hexdigest()

    return hmac.compare_digest(f"sha256={expected}", signature)
