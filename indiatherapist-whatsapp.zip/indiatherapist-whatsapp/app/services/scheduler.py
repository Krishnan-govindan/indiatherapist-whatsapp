"""
Scheduler service — handles therapist notification and session coordination.
"""

import logging
from typing import Optional
from app.services import database as db
from app.services import whatsapp

logger = logging.getLogger(__name__)


async def notify_therapist_new_client(
    therapist: dict,
    client: dict,
) -> bool:
    """
    Send a WhatsApp notification to a therapist about a new client request.
    """
    therapist_phone = therapist.get("phone")
    if not therapist_phone:
        logger.warning(f"Therapist {therapist.get('name')} has no phone number")
        return False

    message = (
        f"🔔 *New Client Request — India Therapist*\n\n"
        f"Hi {therapist.get('name', 'Doctor')},\n\n"
        f"You have a new client interested in scheduling a session:\n\n"
        f"👤 *Name:* {client.get('name', 'Not provided')}\n"
        f"🌍 *Country:* {client.get('country', 'Not provided')}\n"
        f"🗣️ *Language:* {client.get('preferred_language', 'Not specified')}\n"
        f"💭 *Concern:* {client.get('concern', 'Not shared')}\n"
        f"⏰ *Preferred Times:* {client.get('preferred_times', 'Flexible')}\n\n"
        f"Are you available to take this session?\n"
        f"Please reply *YES* or *NO*."
    )

    success = await whatsapp.send_text_message(therapist_phone, message)

    if success:
        logger.info(f"Notified therapist {therapist.get('name')} about client {client.get('name')}")
    return success


async def handle_therapist_response(
    therapist_phone: str,
    response_text: str,
) -> Optional[dict]:
    """
    Handle a therapist's response to a client request.
    Returns action details or None.
    """
    response_lower = response_text.strip().lower()

    # Find the therapist
    therapists = await db.get_all_therapists()
    therapist = None
    for t in therapists:
        if t.get("phone") == therapist_phone:
            therapist = t
            break

    if not therapist:
        return None

    # Find pending sessions for this therapist
    # (In production, you'd have a more sophisticated matching system)
    all_sessions = await db.get_all_sessions()
    pending_session = None
    for s in all_sessions:
        if s.get("therapist_id") == therapist.get("id") and s.get("status") == "pending":
            pending_session = s
            break

    if not pending_session:
        return None

    if response_lower in ("yes", "y", "available", "sure", "ok"):
        return {
            "available": True,
            "therapist": therapist,
            "session": pending_session,
        }
    elif response_lower in ("no", "n", "not available", "unavailable", "busy"):
        return {
            "available": False,
            "therapist": therapist,
            "session": pending_session,
        }

    return None


async def confirm_session_with_client(
    client_phone: str,
    therapist_name: str,
    scheduled_time: str,
    session_price: float,
) -> bool:
    """Send session confirmation details to the client."""
    message = (
        f"✅ *Session Confirmed — India Therapist*\n\n"
        f"Great news! Your session is confirmed:\n\n"
        f"👨‍⚕️ *Therapist:* {therapist_name}\n"
        f"📅 *Scheduled:* {scheduled_time}\n"
        f"💰 *Fee:* ${session_price}\n\n"
        f"A secure payment link will be sent to you shortly.\n"
        f"Once payment is complete, you're all set! 🙏"
    )

    return await whatsapp.send_text_message(client_phone, message)


async def send_payment_reminder(client_phone: str, therapist_name: str, amount: float) -> bool:
    """Send a payment reminder to a client."""
    message = (
        f"💳 *Payment Reminder — India Therapist*\n\n"
        f"Hi! Just a gentle reminder about your upcoming session with {therapist_name}.\n\n"
        f"Session fee: *${amount}*\n\n"
        f"Please complete the payment using the link shared earlier to confirm your session. "
        f"If you have any questions, feel free to ask! 🙏"
    )

    return await whatsapp.send_text_message(client_phone, message)


async def send_post_session_followup(client_phone: str, therapist_name: str) -> bool:
    """Send a post-session follow-up message."""
    message = (
        f"🙏 *How was your session? — India Therapist*\n\n"
        f"Hi! We hope your session with {therapist_name} was helpful.\n\n"
        f"We'd love to hear how it went. Your feedback helps us serve you better.\n\n"
        f"Would you like to book another session? Just let us know! 💙"
    )

    return await whatsapp.send_text_message(client_phone, message)
