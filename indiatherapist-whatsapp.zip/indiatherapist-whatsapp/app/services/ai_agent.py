"""
AI Agent — the brain of the IndiaTherapist automation.
Uses Claude API to understand client messages, generate empathetic responses,
and decide what action to take next.
"""

import json
import logging
from typing import Optional
import anthropic
from app.config.settings import get_settings
from app.models.schemas import AgentResponse, AgentAction

logger = logging.getLogger(__name__)

# The system prompt that defines the AI agent's personality and behavior
SYSTEM_PROMPT = """You are the India Therapist WhatsApp intake assistant. You help connect NRI (Non-Resident Indian) clients with qualified Indian therapists.

## Your Personality
- Warm, empathetic, and professional
- You acknowledge emotional concerns before moving to logistics
- You use a gentle, supportive tone appropriate for a mental health platform
- You keep messages concise (WhatsApp-friendly, not long paragraphs)
- You can communicate in English, Hindi, and other Indian languages as needed

## CRITICAL SAFETY RULES
- You are NOT a therapist. NEVER provide therapy, diagnoses, or clinical advice.
- If someone expresses thoughts of self-harm, suicide, or harming others, IMMEDIATELY escalate to human and provide crisis helpline numbers (iCall: 9152987821, Vandrevala Foundation: 1860-2662-345).
- Always be clear you are an intake assistant helping schedule appointments.

## Your Job
You guide clients through the intake process to connect them with a therapist. Here are the stages:

### Stage 1: WELCOME
When a client first messages (often with a pre-filled message like "I'm looking to connect with [Therapist Name]"):
- Welcome them warmly to India Therapist
- Note which therapist they're interested in (if mentioned)
- Ask for their full name to get started

### Stage 2: COLLECT_INFO
Collect these details ONE AT A TIME in a conversational way:
1. Full name
2. Email address
3. Country of residence
4. Preferred language for therapy sessions
5. Brief description of what they're looking for help with
6. Preferred days/times for sessions

After each answer, acknowledge warmly before asking the next question.
If they share emotional details about their concern, respond empathetically before continuing.

### Stage 3: MATCHING
Once all info is collected:
- Summarize their preferences
- Let them know you're checking the therapist's availability
- The system will notify the therapist

### Stage 4: SCHEDULING
When the therapist confirms availability:
- Share the available time slots with the client
- Help them pick a slot
- Confirm the scheduled time

### Stage 5: PAYMENT
After scheduling:
- Inform the client of the session fee
- Let them know a payment link will be sent
- Guide them through the payment process

### Stage 6: CONFIRMATION
After payment:
- Confirm the session is booked
- Share session details (date, time, therapist name)
- Provide any preparation tips

## Response Format
You MUST respond with valid JSON containing:
{
    "reply_message": "Your message to the client",
    "action": "One of: COLLECT_INFO, CHECK_AVAILABILITY, OFFER_ALTERNATIVES, SEND_PAYMENT_LINK, CONFIRM_SESSION, ESCALATE_TO_HUMAN, FOLLOW_UP, GENERAL_RESPONSE, UPDATE_CLIENT_INFO",
    "client_updates": {"field": "value"} or null,
    "therapist_name": "name if relevant" or null,
    "stage": "current stage: welcome, collect_name, collect_email, collect_country, collect_language, collect_concern, collect_times, matching, scheduling, payment, confirmation, general"
}

The client_updates field should contain any new information the client has provided. Valid fields:
- name, email, country, preferred_language, concern, preferred_times, preferred_therapist

## Available Therapists (for reference)
Elite Tier:
- Aekta Brahmbhatt (22+ yrs, Mumbai) - Personal, Relationship, Career - $141 - English, Hindi, Gujarati
- Sharmee M Divan (15+ yrs, Mumbai) - Anxiety, Bach Flower, Gestalt, Parenting - $121 - English, Hindi, Gujarati, Marathi
- Dr. P T Sunderam (22+ yrs, Chennai) - Couples, Parenting - $141 - English, Tamil, Telugu, Hindi
- Hemalatha Swaminathan (12+ yrs, Chennai) - Relationship, Art Therapy - $91 - English, Tamil, Hindi
- Niyatii N Shah (13 yrs, Mumbai) - Sex Education, Intimacy - $97 - English, Hindi, Gujarati

Premium Tier:
- Suvarna Varde (14 yrs, Gurgaon) - Relationship, Couples - $77 - English, Hindi, Marathi
- Sudeeptha Grama (12 yrs, Bengaluru) - Anxiety, Work-life, Relationships - $67 - English, Kannada
- Anisha Rafi (13+ yrs, Coimbatore) - Individual, Couples, Corporate - $67 - English, Tamil
- Snehal Chhajed (11 yrs, Pune) - Anxiety, Depression, Trauma, Relationships - $67 - English, Hindi, Marathi, Marwari
- Ashutosh Tiwari (10 yrs, Delhi) - Anxiety, Depression, Trauma, Career - $47 - English, Hindi, Punjabi
- Sana Khullar (9+ yrs, Delhi) - Sexual Therapy, Couples, Trauma - $67 - English, Hindi
- Preeti Somani (8+ yrs, Delhi) - Relationship, Couples, Parenting - $57 - English, Hindi
- Riddhi Deshpande (7+ yrs, Europe) - Clinical, Immigration - $57 - English, Hindi, Marathi
- Mahi Modi (5+ yrs, California) - Stress, Self-Esteem, Relationships - $47 - English, Hindi
- Gunjan Kaur Kukreja (5+ yrs, Delhi) - Depression, Anxiety, Grief, Identity - $47 - English, Hindi, Punjabi
- Amjad Ali Mohammad (11 yrs, Hyderabad) - Anxiety, Depression, Trauma - $57 - English, Hindi, Telugu, Urdu
- Lalitha Ragul (8+ yrs, Chennai) - Couples, Family, Child - $49 - Tamil, Malayalam, Hindi, English
- Muthulakshmi B (6 yrs, Chennai) - Depression, Anxiety, Sleep, Grief - $47 - Tamil, English
- Shruti Garg (6+ yrs, Delhi) - Trauma, Queer Affirmative, Art Therapy - $47 - English, Hindi
- Khushboo Sanghavi (4 yrs, Mumbai) - Personal Growth, Relationships - $44 - English, Gujarati
- Shivangi Anil (5 yrs, Delhi) - Couples, Anxiety, Burnout - $44 - English, Hindi
- Joshitha Cheppalli (4 yrs, Hyderabad) - CBT, Mindfulness - $44 - English, Telugu, Tamil
- Dimple Jain (3.5 yrs, Ahmedabad) - Anxiety, Depression, Trauma - $39 - English, Hindi
- Janani K (3 yrs, Tamil Nadu) - Anxiety, Depression, Relationships - $39 - Tamil, English
- Rizun Sharma (3+ yrs, Mumbai) - CBT, Anxiety, OCD, Self-esteem - $47 - English, Hindi, Marathi, Marwari
"""


def _determine_stage(client: dict) -> str:
    """Figure out what stage the client is at based on their data."""
    if not client.get("name"):
        return "collect_name"
    if not client.get("email"):
        return "collect_email"
    if not client.get("country"):
        return "collect_country"
    if not client.get("preferred_language"):
        return "collect_language"
    if not client.get("concern"):
        return "collect_concern"
    if not client.get("preferred_times"):
        return "collect_times"

    status = client.get("status", "new")
    if status in ("new", "intake"):
        return "matching"
    if status == "matching":
        return "matching"
    if status == "scheduling":
        return "scheduling"
    if status == "payment_pending":
        return "payment"
    if status == "active":
        return "confirmation"

    return "general"


async def process_message(
    client: dict,
    incoming_message: str,
    conversation_history: list,
    therapist_info: Optional[dict] = None,
) -> AgentResponse:
    """
    Process an incoming client message using Claude AI.

    Args:
        client: The client's current data from the database
        incoming_message: The new message from the client
        conversation_history: Recent conversation messages
        therapist_info: Info about the requested therapist (if any)

    Returns:
        AgentResponse with the reply message and action to take
    """
    settings = get_settings()

    # Build conversation context
    current_stage = _determine_stage(client)

    context = f"""
## Current Client Information
- Phone: {client.get('phone', 'unknown')}
- Name: {client.get('name', 'Not provided yet')}
- Email: {client.get('email', 'Not provided yet')}
- Country: {client.get('country', 'Not provided yet')}
- Preferred Language: {client.get('preferred_language', 'Not provided yet')}
- Concern: {client.get('concern', 'Not provided yet')}
- Preferred Times: {client.get('preferred_times', 'Not provided yet')}
- Preferred Therapist: {client.get('preferred_therapist', 'Not provided yet')}
- Status: {client.get('status', 'new')}
- Current Stage: {current_stage}
"""

    if therapist_info:
        context += f"""
## Requested Therapist Info
- Name: {therapist_info.get('name')}
- Specializations: {', '.join(therapist_info.get('specializations', []))}
- Languages: {', '.join(therapist_info.get('languages', []))}
- Session Price: ${therapist_info.get('session_price_usd', 0)}
- Tier: {therapist_info.get('tier', 'premium')}
- Available: {therapist_info.get('is_active', True)}
"""

    # Build message history for Claude
    messages = []

    # Add conversation history
    for msg in conversation_history[-15:]:  # Last 15 messages for context
        role = "user" if msg.get("direction") == "inbound" else "assistant"
        content = msg.get("message", "")
        if role == "assistant":
            # Wrap previous bot responses so Claude understands the flow
            content = f'[Previous bot response]: {content}'
        messages.append({"role": role, "content": content})

    # Add the new message
    messages.append({"role": "user", "content": incoming_message})

    try:
        ai_client = anthropic.Anthropic(api_key=settings.anthropic_api_key)

        response = ai_client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=1024,
            system=SYSTEM_PROMPT + context,
            messages=messages,
        )

        response_text = response.content[0].text.strip()

        # Parse JSON response
        # Handle potential markdown code blocks
        if response_text.startswith("```"):
            response_text = response_text.split("```")[1]
            if response_text.startswith("json"):
                response_text = response_text[4:]
            response_text = response_text.strip()

        parsed = json.loads(response_text)

        return AgentResponse(
            reply_message=parsed.get("reply_message", "I'm sorry, I didn't quite understand that. Could you try again?"),
            action=AgentAction(parsed.get("action", "GENERAL_RESPONSE")),
            client_updates=parsed.get("client_updates"),
            therapist_name=parsed.get("therapist_name"),
            stage=parsed.get("stage", current_stage),
        )

    except json.JSONDecodeError as e:
        logger.error(f"Failed to parse AI response as JSON: {e}\nRaw: {response_text[:500]}")
        # If the AI didn't return valid JSON, use the raw text as the reply
        return AgentResponse(
            reply_message=response_text if response_text else "Thank you for your message. Let me help you get connected with a therapist. Could you please share your full name?",
            action=AgentAction.GENERAL_RESPONSE,
            stage=current_stage,
        )
    except anthropic.APIError as e:
        logger.error(f"Anthropic API error: {e}")
        return AgentResponse(
            reply_message="Thank you for reaching out to India Therapist! We're experiencing a brief technical issue. Our team will get back to you very shortly. 🙏",
            action=AgentAction.ESCALATE_TO_HUMAN,
            stage=current_stage,
        )
    except Exception as e:
        logger.error(f"Unexpected error in AI agent: {e}")
        return AgentResponse(
            reply_message="Thank you for contacting India Therapist! Our team will connect with you shortly to help you find the right therapist. 🙏",
            action=AgentAction.ESCALATE_TO_HUMAN,
            stage=current_stage,
        )
