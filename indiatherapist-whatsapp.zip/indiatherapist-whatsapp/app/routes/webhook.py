"""
WhatsApp Webhook Route — handles incoming messages and verification.
This is the main entry point for all WhatsApp communication.
"""

import logging
from fastapi import APIRouter, Request, Query, HTTPException
from app.config.settings import get_settings
from app.services import whatsapp, database as db, ai_agent, scheduler, payment
from app.models.schemas import AgentAction

logger = logging.getLogger(__name__)
router = APIRouter()


@router.get("/webhook")
async def verify_webhook(
    hub_mode: str = Query(None, alias="hub.mode"),
    hub_verify_token: str = Query(None, alias="hub.verify_token"),
    hub_challenge: str = Query(None, alias="hub.challenge"),
):
    """
    WhatsApp webhook verification endpoint.
    Meta sends a GET request to verify your webhook URL.
    """
    settings = get_settings()

    if hub_mode == "subscribe" and hub_verify_token == settings.whatsapp_verify_token:
        logger.info("Webhook verified successfully")
        return int(hub_challenge)

    logger.warning(f"Webhook verification failed: mode={hub_mode}")
    raise HTTPException(status_code=403, detail="Verification failed")


@router.post("/webhook")
async def handle_webhook(request: Request):
    """
    Main webhook handler — processes all incoming WhatsApp messages.
    This is the core message processing pipeline.
    """
    body = await request.json()

    # Parse the incoming message
    parsed = whatsapp.parse_webhook_message(body)
    if not parsed:
        # Could be a status update (delivered, read) — acknowledge silently
        return {"status": "ok"}

    from_number = parsed["from_number"]
    message_text = parsed["message_text"]
    message_id = parsed["message_id"]
    sender_name = parsed.get("sender_name", "")

    logger.info(f"Message from {from_number}: {message_text[:100]}")

    # Mark message as read (blue ticks)
    await whatsapp.mark_message_read(message_id)

    # ── Step 1: Get or create client ──────────────────────
    client = await db.get_client_by_phone(from_number)
    if not client:
        # New client — create record
        initial_data = {"sender_name": sender_name}

        # Check if they mentioned a therapist in the pre-filled message
        therapist_name = _extract_therapist_name(message_text)
        if therapist_name:
            initial_data["preferred_therapist"] = therapist_name

        client = await db.create_client(from_number, initial_data)
        logger.info(f"New client created: {from_number}")

    client_id = client.get("id", from_number)

    # ── Step 2: Check human takeover ─────────────────────
    if await db.is_human_takeover(from_number):
        # Bot is paused — just log the message for the admin to see
        await db.log_message(client_id, "inbound", message_text, "human_takeover")
        logger.info(f"Human takeover active for {from_number}, message logged only")
        return {"status": "ok"}

    # ── Step 3: Log incoming message ─────────────────────
    await db.log_message(client_id, "inbound", message_text)

    # ── Step 4: Get conversation history ─────────────────
    history = await db.get_conversation_history(client_id, limit=20)

    # ── Step 5: Get therapist info if requested ──────────
    therapist_info = None
    preferred = client.get("preferred_therapist")
    if preferred:
        therapist_info = await db.get_therapist_by_name(preferred)

    # ── Step 6: Process with AI agent ────────────────────
    agent_response = await ai_agent.process_message(
        client=client,
        incoming_message=message_text,
        conversation_history=history,
        therapist_info=therapist_info,
    )

    # ── Step 7: Execute the agent's action ───────────────
    await _execute_action(client, agent_response, from_number)

    # ── Step 8: Send reply to client ─────────────────────
    await whatsapp.send_text_message(from_number, agent_response.reply_message)

    # ── Step 9: Log outgoing message ─────────────────────
    await db.log_message(client_id, "outbound", agent_response.reply_message, agent_response.stage)

    return {"status": "ok"}


def _extract_therapist_name(message: str) -> str | None:
    """Extract therapist name from a pre-filled booking message."""
    # Common patterns from the website's wa.me links
    patterns = [
        "I'm looking to connect with ",
        "I would like to take a session from Coach ",
        "I would like to take a session from ",
        "looking to connect with ",
        "connect with ",
        "session with ",
        "session from ",
    ]

    message_lower = message.lower()
    for pattern in patterns:
        pattern_lower = pattern.lower()
        idx = message_lower.find(pattern_lower)
        if idx != -1:
            remainder = message[idx + len(pattern):]
            # Remove trailing punctuation and "Can you help me out?" type endings
            for ending in [". Can you", ".Can you", "? Can you", ". can you", "?", "."]:
                end_idx = remainder.find(ending)
                if end_idx != -1:
                    remainder = remainder[:end_idx]
            return remainder.strip()

    return None


async def _execute_action(client: dict, response, from_number: str):
    """Execute the action recommended by the AI agent."""
    client_id = client.get("id", from_number)

    # Update client info if the AI extracted new data
    if response.client_updates:
        await db.update_client(from_number, response.client_updates)

    # Update client status based on stage
    stage_to_status = {
        "collect_name": "intake",
        "collect_email": "intake",
        "collect_country": "intake",
        "collect_language": "intake",
        "collect_concern": "intake",
        "collect_times": "intake",
        "matching": "matching",
        "scheduling": "scheduling",
        "payment": "payment_pending",
        "confirmation": "active",
    }
    new_status = stage_to_status.get(response.stage)
    if new_status and new_status != client.get("status"):
        await db.update_client(from_number, {"status": new_status})

    # Handle specific actions
    if response.action == AgentAction.CHECK_AVAILABILITY:
        await _handle_check_availability(client, response)

    elif response.action == AgentAction.SEND_PAYMENT_LINK:
        await _handle_send_payment(client, response, from_number)

    elif response.action == AgentAction.ESCALATE_TO_HUMAN:
        await _handle_escalation(client, from_number)

    elif response.action == AgentAction.OFFER_ALTERNATIVES:
        await _handle_alternatives(client, response, from_number)


async def _handle_check_availability(client: dict, response):
    """Notify the therapist about a new client request."""
    therapist_name = response.therapist_name or client.get("preferred_therapist")
    if not therapist_name:
        return

    therapist = await db.get_therapist_by_name(therapist_name)
    if not therapist:
        return

    # Create a session record
    await db.create_session(
        client_id=client.get("id"),
        therapist_id=therapist.get("id"),
        amount_usd=therapist.get("session_price_usd", 0),
    )

    # Notify the therapist via WhatsApp
    await scheduler.notify_therapist_new_client(therapist, client)

    # Update client status
    await db.update_client(client.get("phone"), {"status": "matching"})


async def _handle_send_payment(client: dict, response, from_number: str):
    """Generate and send a payment link."""
    pending = await db.get_pending_payment_session(client.get("id"))
    if not pending:
        return

    therapist_data = pending.get("therapists", {})
    amount = pending.get("amount_usd") or therapist_data.get("session_price_usd", 0)

    payment_url = await payment.generate_payment_link(
        amount_usd=amount,
        client_name=client.get("name", ""),
        client_email=client.get("email", ""),
        client_phone=from_number,
        session_id=pending.get("id", ""),
        therapist_name=therapist_data.get("name", "Therapist"),
    )

    if payment_url:
        from app.templates.messages import payment_link_message
        msg = payment_link_message(therapist_data.get("name", "Therapist"), amount, payment_url)
        await whatsapp.send_text_message(from_number, msg)
        await db.log_message(client.get("id"), "outbound", msg, "payment")


async def _handle_escalation(client: dict, from_number: str):
    """Handle escalation to human admin."""
    await db.set_human_takeover(from_number, True)

    # Notify admin (you could also send a WhatsApp to the admin number)
    logger.warning(f"🚨 ESCALATION: Client {client.get('name', from_number)} needs human attention")

    # Send escalation message to the admin's WhatsApp
    settings = get_settings()
    admin_msg = (
        f"🚨 *ESCALATION ALERT*\n\n"
        f"Client needs human attention:\n"
        f"👤 {client.get('name', 'Unknown')}\n"
        f"📱 {from_number}\n"
        f"💭 Last concern: {client.get('concern', 'Not specified')}\n\n"
        f"Bot has been paused for this client. "
        f"Please respond directly via the admin dashboard."
    )
    # Send to the India Therapist admin number
    await whatsapp.send_text_message("14254424167", admin_msg)


async def _handle_alternatives(client: dict, response, from_number: str):
    """Suggest alternative therapists."""
    exclude = response.therapist_name or client.get("preferred_therapist", "")
    languages = [client.get("preferred_language")] if client.get("preferred_language") else []

    alternatives = await db.get_alternative_therapists(exclude, languages)
    if alternatives:
        from app.templates.messages import therapist_unavailable
        msg = therapist_unavailable(exclude, alternatives)
        await whatsapp.send_text_message(from_number, msg)
        await db.log_message(client.get("id"), "outbound", msg, "alternatives")
