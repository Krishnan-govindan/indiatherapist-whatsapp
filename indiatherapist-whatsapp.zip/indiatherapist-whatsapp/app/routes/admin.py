"""
Admin API routes — powers the admin dashboard.
Provides endpoints for viewing clients, conversations, sessions,
and managing the bot (human takeover, manual messages, etc.)
"""

import logging
from fastapi import APIRouter, HTTPException, Depends, Header
from typing import Optional
from app.config.settings import get_settings
from app.services import database as db, whatsapp
from app.models.schemas import ManualMessageRequest

logger = logging.getLogger(__name__)
router = APIRouter()


def verify_admin(x_admin_password: Optional[str] = Header(None)):
    """Simple password-based admin auth via header."""
    settings = get_settings()
    if x_admin_password != settings.admin_password:
        raise HTTPException(status_code=401, detail="Invalid admin password")
    return True


# ─── Dashboard Stats ──────────────────────────────────────

@router.get("/stats")
async def get_stats(auth: bool = Depends(verify_admin)):
    """Get dashboard summary statistics."""
    return await db.get_dashboard_stats()


# ─── Client Management ────────────────────────────────────

@router.get("/clients")
async def get_clients(auth: bool = Depends(verify_admin)):
    """Get all clients."""
    return await db.get_all_clients()


@router.get("/clients/{phone}/conversations")
async def get_client_conversations(phone: str, auth: bool = Depends(verify_admin)):
    """Get conversation history for a specific client."""
    client = await db.get_client_by_phone(phone)
    if not client:
        raise HTTPException(status_code=404, detail="Client not found")

    conversations = await db.get_conversation_history(client["id"], limit=100)
    return {
        "client": client,
        "conversations": conversations,
    }


# ─── Therapist Management ─────────────────────────────────

@router.get("/therapists")
async def get_therapists(auth: bool = Depends(verify_admin)):
    """Get all therapists."""
    return await db.get_all_therapists(active_only=False)


# ─── Session Management ───────────────────────────────────

@router.get("/sessions")
async def get_sessions(auth: bool = Depends(verify_admin)):
    """Get all sessions with client and therapist info."""
    return await db.get_all_sessions()


@router.patch("/sessions/{session_id}")
async def update_session(session_id: str, updates: dict, auth: bool = Depends(verify_admin)):
    """Update a session (status, payment, schedule)."""
    result = await db.update_session(session_id, updates)
    if not result:
        raise HTTPException(status_code=404, detail="Session not found")
    return result


# ─── Conversation Monitoring ──────────────────────────────

@router.get("/conversations")
async def get_all_conversations(limit: int = 100, auth: bool = Depends(verify_admin)):
    """Get all recent conversations across all clients."""
    return await db.get_all_conversations(limit=limit)


# ─── Human Takeover ───────────────────────────────────────

@router.post("/takeover/{phone}")
async def enable_takeover(phone: str, auth: bool = Depends(verify_admin)):
    """Enable human takeover for a client (pauses the bot)."""
    await db.set_human_takeover(phone, True)
    return {"status": "takeover_enabled", "phone": phone}


@router.delete("/takeover/{phone}")
async def disable_takeover(phone: str, auth: bool = Depends(verify_admin)):
    """Disable human takeover (resumes the bot)."""
    await db.set_human_takeover(phone, False)
    return {"status": "takeover_disabled", "phone": phone}


# ─── Manual Messaging ─────────────────────────────────────

@router.post("/send-message")
async def send_manual_message(req: ManualMessageRequest, auth: bool = Depends(verify_admin)):
    """Send a manual message to a client (as admin, bypassing the bot)."""
    success = await whatsapp.send_text_message(req.client_phone, req.message)
    if not success:
        raise HTTPException(status_code=500, detail="Failed to send message")

    # Log the manual message
    client = await db.get_client_by_phone(req.client_phone)
    if client:
        await db.log_message(client["id"], "outbound", f"[ADMIN] {req.message}", "manual")

    return {"status": "sent", "phone": req.client_phone}
