"""
Payment webhook routes — handles callbacks from Razorpay and Stripe
when payments succeed, fail, or are refunded.
"""

import logging
import json
from fastapi import APIRouter, Request, HTTPException, Query
from app.services import database as db, whatsapp
from app.templates.messages import payment_confirmed_message
from app.config.settings import get_settings

logger = logging.getLogger(__name__)
router = APIRouter()


@router.post("/razorpay/webhook")
async def razorpay_webhook(request: Request):
    """Handle Razorpay payment webhooks."""
    try:
        body = await request.json()
        event = body.get("event", "")

        if event == "payment_link.paid":
            payload = body.get("payload", {})
            payment_link = payload.get("payment_link", {}).get("entity", {})
            notes = payment_link.get("notes", {})
            session_id = notes.get("session_id")
            therapist_name = notes.get("therapist", "your therapist")

            if session_id:
                # Update session payment status
                payment_id = payment_link.get("id", "")
                await db.update_session(session_id, {
                    "payment_status": "paid",
                    "payment_id": payment_id,
                    "status": "confirmed",
                })

                # Notify the client
                session = await db.get_all_sessions()
                for s in session:
                    if s.get("id") == session_id:
                        client_info = s.get("clients", {})
                        client_phone = client_info.get("phone")
                        if client_phone:
                            msg = payment_confirmed_message(therapist_name)
                            await whatsapp.send_text_message(client_phone, msg)

                            # Log the confirmation
                            client = await db.get_client_by_phone(client_phone)
                            if client:
                                await db.log_message(client["id"], "outbound", msg, "payment_confirmed")
                                await db.update_client(client_phone, {"status": "active"})

                        # Notify the therapist
                        therapist_info = s.get("therapists", {})
                        therapist_phone = therapist_info.get("phone")
                        if therapist_phone:
                            t_msg = (
                                f"✅ *Payment Received — India Therapist*\n\n"
                                f"Payment confirmed for your session with {client_info.get('name', 'the client')}.\n"
                                f"Please reach out to schedule the session details.\n"
                                f"Client contact: {client_phone}\n\n"
                                f"Thank you! 🙏"
                            )
                            await whatsapp.send_text_message(therapist_phone, t_msg)
                        break

                logger.info(f"Payment confirmed for session {session_id}")

        return {"status": "ok"}

    except Exception as e:
        logger.error(f"Error processing Razorpay webhook: {e}")
        return {"status": "error"}


@router.get("/razorpay/callback")
async def razorpay_callback(
    razorpay_payment_id: str = Query(None),
    razorpay_payment_link_id: str = Query(None),
    razorpay_payment_link_status: str = Query(None),
):
    """Razorpay payment callback (redirect after payment)."""
    if razorpay_payment_link_status == "paid":
        return {"message": "Payment successful! Thank you. Your session is confirmed. You can close this page."}
    return {"message": "Payment status: " + str(razorpay_payment_link_status)}


@router.get("/stripe/success")
async def stripe_success(session_id: str = Query(None)):
    """Stripe success redirect."""
    if session_id:
        await db.update_session(session_id, {
            "payment_status": "paid",
            "status": "confirmed",
        })
    return {"message": "Payment successful! Thank you. Your session is confirmed. You can close this page."}


@router.get("/stripe/cancel")
async def stripe_cancel(session_id: str = Query(None)):
    """Stripe cancel redirect."""
    return {"message": "Payment was cancelled. You can return to WhatsApp to try again or contact us for help."}


@router.post("/stripe/webhook")
async def stripe_webhook(request: Request):
    """Handle Stripe payment webhooks."""
    settings = get_settings()
    payload = await request.body()

    try:
        import stripe
        stripe.api_key = settings.stripe_secret_key

        sig_header = request.headers.get("stripe-signature", "")

        if settings.stripe_webhook_secret:
            event = stripe.Webhook.construct_event(
                payload, sig_header, settings.stripe_webhook_secret
            )
        else:
            event = json.loads(payload)

        if event["type"] == "checkout.session.completed":
            checkout = event["data"]["object"]
            session_id = checkout.get("metadata", {}).get("session_id")
            therapist_name = checkout.get("metadata", {}).get("therapist", "your therapist")

            if session_id:
                await db.update_session(session_id, {
                    "payment_status": "paid",
                    "payment_id": checkout.get("payment_intent", ""),
                    "status": "confirmed",
                })

                # Find and notify client
                all_sessions = await db.get_all_sessions()
                for s in all_sessions:
                    if s.get("id") == session_id:
                        client_info = s.get("clients", {})
                        client_phone = client_info.get("phone")
                        if client_phone:
                            msg = payment_confirmed_message(therapist_name)
                            await whatsapp.send_text_message(client_phone, msg)
                            client = await db.get_client_by_phone(client_phone)
                            if client:
                                await db.log_message(client["id"], "outbound", msg, "payment_confirmed")
                                await db.update_client(client_phone, {"status": "active"})
                        break

                logger.info(f"Stripe payment confirmed for session {session_id}")

        return {"status": "ok"}

    except Exception as e:
        logger.error(f"Error processing Stripe webhook: {e}")
        raise HTTPException(status_code=400, detail=str(e))
