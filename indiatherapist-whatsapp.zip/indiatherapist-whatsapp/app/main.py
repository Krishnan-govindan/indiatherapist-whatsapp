"""
IndiaTherapist WhatsApp Automation Platform
Main FastAPI application entry point.
"""

import logging
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pathlib import Path

from app.routes import webhook, admin, payments

# ─── Logging Setup ────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)

# ─── FastAPI App ──────────────────────────────────────────
app = FastAPI(
    title="IndiaTherapist WhatsApp Automation",
    description="AI-powered WhatsApp bot for connecting NRIs with Indian therapists",
    version="1.0.0",
)

# ─── CORS (allows admin dashboard to call the API) ───────
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, restrict to your admin domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─── Routes ───────────────────────────────────────────────
app.include_router(webhook.router, prefix="/api/whatsapp", tags=["WhatsApp"])
app.include_router(admin.router, prefix="/api/admin", tags=["Admin"])
app.include_router(payments.router, prefix="/api/payments", tags=["Payments"])


# ─── Health Check ─────────────────────────────────────────
@app.get("/")
async def root():
    return {
        "app": "IndiaTherapist WhatsApp Automation",
        "status": "running",
        "version": "1.0.0",
        "docs": "/docs",
    }


@app.get("/health")
async def health_check():
    return {"status": "healthy"}


# ─── Serve Admin Dashboard ───────────────────────────────
DASHBOARD_PATH = Path(__file__).parent.parent / "admin-dashboard" / "index.html"


@app.get("/admin")
async def serve_admin():
    """Serve the admin dashboard."""
    if DASHBOARD_PATH.exists():
        return FileResponse(DASHBOARD_PATH, media_type="text/html")
    return {"error": "Admin dashboard not found", "path": str(DASHBOARD_PATH)}


# ─── Startup Event ────────────────────────────────────────
@app.on_event("startup")
async def startup_event():
    logger.info("=" * 60)
    logger.info("  IndiaTherapist WhatsApp Automation — Starting Up")
    logger.info("=" * 60)
    logger.info("API Docs available at /docs")
    logger.info("Admin Dashboard at /admin")
    logger.info("WhatsApp Webhook at /api/whatsapp/webhook")
    logger.info("=" * 60)
