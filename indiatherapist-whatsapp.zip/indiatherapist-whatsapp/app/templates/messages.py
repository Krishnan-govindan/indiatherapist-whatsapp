"""
WhatsApp message templates and helper functions.
These are used for structured messages sent by the bot.
"""


def welcome_message(client_name: str = None) -> str:
    name_part = f" {client_name}" if client_name else ""
    return (
        f"🙏 Welcome{name_part} to *India Therapist*!\n\n"
        f"We connect NRIs with top Indian therapists who understand your "
        f"cultural background and unique challenges.\n\n"
        f"I'm here to help you find the right therapist. "
        f"Let me collect a few details to get started.\n\n"
        f"Could you please share your *full name*?"
    )


def info_collected_summary(client: dict) -> str:
    return (
        f"📋 *Here's a summary of your details:*\n\n"
        f"👤 Name: {client.get('name', '-')}\n"
        f"📧 Email: {client.get('email', '-')}\n"
        f"🌍 Country: {client.get('country', '-')}\n"
        f"🗣️ Language: {client.get('preferred_language', '-')}\n"
        f"💭 Concern: {client.get('concern', '-')}\n"
        f"⏰ Preferred Times: {client.get('preferred_times', '-')}\n"
        f"👨‍⚕️ Therapist: {client.get('preferred_therapist', 'Any available')}\n\n"
        f"I'm now checking your therapist's availability. "
        f"I'll get back to you shortly! 🙏"
    )


def therapist_unavailable(therapist_name: str, alternatives: list) -> str:
    alt_list = ""
    for i, t in enumerate(alternatives[:3], 1):
        alt_list += (
            f"\n{i}. *{t.get('name')}* — {t.get('tier', 'premium').title()} "
            f"(${t.get('session_price_usd', 0)})\n"
            f"   Specializes in: {', '.join(t.get('specializations', [])[:3])}\n"
            f"   Languages: {', '.join(t.get('languages', []))}\n"
        )

    return (
        f"I'm sorry, *{therapist_name}* is not available at the moment.\n\n"
        f"Here are some excellent alternative therapists who might be a great fit:\n"
        f"{alt_list}\n"
        f"Would you like to connect with any of them? "
        f"Just let me know the number or name! 🙏"
    )


def payment_link_message(therapist_name: str, amount: float, payment_url: str) -> str:
    return (
        f"💳 *Payment for Your Session*\n\n"
        f"Therapist: *{therapist_name}*\n"
        f"Session Fee: *${amount}*\n\n"
        f"Please complete your payment using this secure link:\n"
        f"👉 {payment_url}\n\n"
        f"Once payment is confirmed, your session is all set! ✅"
    )


def payment_confirmed_message(therapist_name: str, scheduled_time: str = None) -> str:
    time_part = f"\n📅 Scheduled: *{scheduled_time}*" if scheduled_time else ""
    return (
        f"✅ *Payment Confirmed!*\n\n"
        f"Thank you! Your payment has been received.{time_part}\n"
        f"👨‍⚕️ Therapist: *{therapist_name}*\n\n"
        f"Your therapist will reach out to you with the session link and details.\n\n"
        f"If you have any questions before the session, feel free to ask. "
        f"We wish you a wonderful experience! 💙🙏"
    )


def escalation_message() -> str:
    return (
        f"🤝 I've notified our team, and a human coordinator will be with you shortly.\n\n"
        f"If this is urgent, you can also reach us directly at:\n"
        f"📞 WhatsApp: +1-425-442-4167\n\n"
        f"We're here for you. 💙"
    )


def crisis_message() -> str:
    return (
        f"💙 I can hear that you're going through a really difficult time, "
        f"and I want you to know that help is available right now.\n\n"
        f"Please reach out to these helplines — they're free and confidential:\n\n"
        f"🇮🇳 *iCall*: 9152987821\n"
        f"🇮🇳 *Vandrevala Foundation*: 1860-2662-345 (24/7)\n"
        f"🇺🇸 *988 Suicide & Crisis Lifeline*: Call or text 988\n"
        f"🌍 *Crisis Text Line*: Text HOME to 741741\n\n"
        f"I've also alerted our team. Someone will reach out to you personally. "
        f"You are not alone. 🙏"
    )
