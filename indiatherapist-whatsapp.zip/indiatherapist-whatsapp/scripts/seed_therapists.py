"""
Seed the database with all IndiaTherapist.com therapists.
Run this once after setting up Supabase.

Usage: python scripts/seed_therapists.py
"""

import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from dotenv import load_dotenv
load_dotenv()

from supabase import create_client

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_SERVICE_KEY")

if not SUPABASE_URL or not SUPABASE_KEY:
    print("ERROR: Set SUPABASE_URL and SUPABASE_SERVICE_KEY in your .env file")
    sys.exit(1)

db = create_client(SUPABASE_URL, SUPABASE_KEY)

THERAPISTS = [
    {
        "name": "Aekta Brahmbhatt",
        "specializations": ["Personal Counselling", "Relationship Counselling", "Career Counselling"],
        "languages": ["English", "Hindi", "Gujarati"],
        "tier": "elite",
        "session_price_usd": 141,
        "location": "Mumbai, India",
        "experience_years": 22,
        "is_active": True,
        "phone": "",  # Fill in therapist's WhatsApp number
        "email": "",
    },
    {
        "name": "Sharmee M Divan",
        "specializations": ["Anxiety", "Bach Flower Therapy", "EFT", "Gestalt Therapy", "Conscious Parenting", "Play Therapy"],
        "languages": ["English", "Hindi", "Gujarati", "Marathi"],
        "tier": "elite",
        "session_price_usd": 121,
        "location": "Mumbai, India",
        "experience_years": 15,
        "is_active": True,
        "phone": "",
        "email": "",
    },
    {
        "name": "Dr. P T Sunderam",
        "specializations": ["Married Couples Relationships", "Parenting"],
        "languages": ["English", "Tamil", "Telugu", "Hindi"],
        "tier": "elite",
        "session_price_usd": 141,
        "location": "Chennai, India",
        "experience_years": 22,
        "is_active": True,
        "phone": "",
        "email": "",
    },
    {
        "name": "Hemalatha Swaminathan",
        "specializations": ["Relationship Counselling", "Creative Art Therapy"],
        "languages": ["English", "Tamil", "Hindi"],
        "tier": "elite",
        "session_price_usd": 91,
        "location": "Chennai, India",
        "experience_years": 12,
        "is_active": True,
        "phone": "",
        "email": "",
    },
    {
        "name": "Niyatii N Shah",
        "specializations": ["Sex Education", "Intimacy Coaching"],
        "languages": ["English", "Hindi", "Gujarati"],
        "tier": "elite",
        "session_price_usd": 97,
        "location": "Mumbai, India",
        "experience_years": 13,
        "is_active": True,
        "phone": "",
        "email": "",
    },
    {
        "name": "Suvarna Varde",
        "specializations": ["Relationship Therapy", "Couples Counselling"],
        "languages": ["English", "Hindi", "Marathi"],
        "tier": "premium",
        "session_price_usd": 77,
        "location": "Gurgaon, India",
        "experience_years": 14,
        "is_active": True,
        "phone": "",
        "email": "",
    },
    {
        "name": "Sudeeptha Grama",
        "specializations": ["Anxiety", "Work-life Balance", "Relationship Conflicts", "Communication"],
        "languages": ["English", "Kannada"],
        "tier": "premium",
        "session_price_usd": 67,
        "location": "Bengaluru, India",
        "experience_years": 12,
        "is_active": True,
        "phone": "",
        "email": "",
    },
    {
        "name": "Anisha Rafi",
        "specializations": ["Individual Counseling", "Couple Counseling", "Mentoring", "Corporate Training"],
        "languages": ["English", "Tamil"],
        "tier": "premium",
        "session_price_usd": 67,
        "location": "Coimbatore, India",
        "experience_years": 13,
        "is_active": True,
        "phone": "",
        "email": "",
    },
    {
        "name": "Snehal Chhajed",
        "specializations": ["Anxiety", "Depression", "Trauma", "Relationship Issues", "Infidelity", "Divorce Recovery"],
        "languages": ["English", "Hindi", "Marathi", "Marwari"],
        "tier": "premium",
        "session_price_usd": 67,
        "location": "Pune, India",
        "experience_years": 11,
        "is_active": True,
        "phone": "",
        "email": "",
    },
    {
        "name": "Ashutosh Tiwari",
        "specializations": ["Anxiety", "Depression", "Trauma", "Relationship Issues", "Career Stress"],
        "languages": ["English", "Hindi", "Punjabi"],
        "tier": "premium",
        "session_price_usd": 47,
        "location": "Delhi, India",
        "experience_years": 10,
        "is_active": True,
        "phone": "",
        "email": "",
    },
    {
        "name": "Sana Khullar",
        "specializations": ["Sexual Therapy", "Couples Therapy", "Trauma", "Abuse"],
        "languages": ["English", "Hindi"],
        "tier": "premium",
        "session_price_usd": 67,
        "location": "Delhi, India",
        "experience_years": 9,
        "is_active": True,
        "phone": "",
        "email": "",
    },
    {
        "name": "Preeti Somani",
        "specializations": ["Relationship Counseling", "Couple Counseling", "Parenting", "Emotional Distress"],
        "languages": ["English", "Hindi"],
        "tier": "premium",
        "session_price_usd": 57,
        "location": "Delhi, India",
        "experience_years": 8,
        "is_active": True,
        "phone": "",
        "email": "",
    },
    {
        "name": "Riddhi Deshpande",
        "specializations": ["Clinical Counselling", "Immigration Counselling"],
        "languages": ["English", "Hindi", "Marathi"],
        "tier": "premium",
        "session_price_usd": 57,
        "location": "Europe",
        "experience_years": 7,
        "is_active": True,
        "phone": "",
        "email": "",
    },
    {
        "name": "Mahi Modi",
        "specializations": ["Stress", "Work-life Balance", "Self-Esteem", "Depression", "Anxiety", "Relationship Conflict"],
        "languages": ["English", "Hindi"],
        "tier": "premium",
        "session_price_usd": 47,
        "location": "California, USA",
        "experience_years": 5,
        "is_active": True,
        "phone": "",
        "email": "",
    },
    {
        "name": "Gunjan Kaur Kukreja",
        "specializations": ["Depression", "Anxiety", "Relationship Concerns", "Self-esteem", "Grief", "Identity", "Addiction"],
        "languages": ["English", "Hindi", "Punjabi"],
        "tier": "premium",
        "session_price_usd": 47,
        "location": "Delhi, India",
        "experience_years": 5,
        "is_active": True,
        "phone": "",
        "email": "",
    },
    {
        "name": "Amjad Ali Mohammad",
        "specializations": ["Anxiety", "Depression", "Trauma", "Relationship Issues", "Career Stress"],
        "languages": ["English", "Hindi", "Telugu", "Urdu"],
        "tier": "premium",
        "session_price_usd": 57,
        "location": "Hyderabad, India",
        "experience_years": 11,
        "is_active": True,
        "phone": "",
        "email": "",
    },
    {
        "name": "Lalitha Ragul",
        "specializations": ["Couple Therapy", "Family Counselling", "Parenting", "Child & Adolescent Counselling"],
        "languages": ["Tamil", "Malayalam", "Hindi", "English"],
        "tier": "premium",
        "session_price_usd": 49,
        "location": "Chennai, India",
        "experience_years": 8,
        "is_active": True,
        "phone": "",
        "email": "",
    },
    {
        "name": "Muthulakshmi Balasubramanian",
        "specializations": ["Depression", "Anxiety", "Relationship Counselling", "Sleep Problems", "Grief", "Phobias"],
        "languages": ["Tamil", "English"],
        "tier": "premium",
        "session_price_usd": 47,
        "location": "Chennai, India",
        "experience_years": 6,
        "is_active": True,
        "phone": "",
        "email": "",
    },
    {
        "name": "Shruti Garg",
        "specializations": ["Trauma", "Queer Affirmative Therapy", "Creative Arts Therapy", "Grief", "Anxiety", "Depression"],
        "languages": ["English", "Hindi", "Haryanvi"],
        "tier": "premium",
        "session_price_usd": 47,
        "location": "Delhi, India",
        "experience_years": 6,
        "is_active": True,
        "phone": "",
        "email": "",
    },
    {
        "name": "Khushboo Sanghavi",
        "specializations": ["Personal Growth", "Relationship Issues", "Family Problems", "Depression"],
        "languages": ["English", "Gujarati"],
        "tier": "premium",
        "session_price_usd": 44,
        "location": "Mumbai, India",
        "experience_years": 4,
        "is_active": True,
        "phone": "",
        "email": "",
    },
    {
        "name": "Shivangi Anil",
        "specializations": ["Couple Therapy", "Anxiety", "Depression", "Work Stress", "Burnout"],
        "languages": ["English", "Hindi"],
        "tier": "premium",
        "session_price_usd": 44,
        "location": "Delhi, India",
        "experience_years": 5,
        "is_active": True,
        "phone": "",
        "email": "",
    },
    {
        "name": "Joshitha Cheppalli",
        "specializations": ["CBT", "Mindfulness"],
        "languages": ["English", "Telugu", "Tamil"],
        "tier": "premium",
        "session_price_usd": 44,
        "location": "Hyderabad, India",
        "experience_years": 4,
        "is_active": True,
        "phone": "",
        "email": "",
    },
    {
        "name": "Dimple Jain",
        "specializations": ["Anxiety", "Depression", "Trauma", "Relationship Issues", "Career Stress"],
        "languages": ["English", "Hindi"],
        "tier": "premium",
        "session_price_usd": 39,
        "location": "Ahmedabad, India",
        "experience_years": 3,
        "is_active": True,
        "phone": "",
        "email": "",
    },
    {
        "name": "Janani K",
        "specializations": ["Anxiety", "Depression", "Trauma", "Relationship Issues", "Career Stress", "Divorce Recovery"],
        "languages": ["Tamil", "English"],
        "tier": "premium",
        "session_price_usd": 39,
        "location": "Tamil Nadu, India",
        "experience_years": 3,
        "is_active": True,
        "phone": "",
        "email": "",
    },
    {
        "name": "Rizun Sharma",
        "specializations": ["CBT", "Anxiety", "Stress", "Depression", "OCD", "Self-esteem", "Suicide Prevention"],
        "languages": ["English", "Hindi", "Marathi", "Marwari"],
        "tier": "premium",
        "session_price_usd": 47,
        "location": "Mumbai, India",
        "experience_years": 3,
        "is_active": True,
        "phone": "",
        "email": "",
    },
]


def seed():
    print(f"Seeding {len(THERAPISTS)} therapists...")
    for t in THERAPISTS:
        try:
            # Check if therapist already exists
            existing = db.table("therapists").select("id").ilike("name", t["name"]).execute()
            if existing.data:
                print(f"  ✓ {t['name']} already exists, skipping")
                continue

            result = db.table("therapists").insert(t).execute()
            print(f"  ✓ Added: {t['name']}")
        except Exception as e:
            print(f"  ✗ Error adding {t['name']}: {e}")

    print(f"\nDone! Seeded therapists into Supabase.")


if __name__ == "__main__":
    seed()
