# IndiaTherapist WhatsApp Automation Platform

## Project Overview
Automated WhatsApp-based client management system for IndiaTherapist.com.
Replaces manual WhatsApp coordination with an AI-powered conversational agent
that handles client intake, therapist matching, session scheduling, and payment collection.

## Tech Stack
- **Backend**: Python 3.11+ / FastAPI
- **AI Agent**: Anthropic Claude API (claude-sonnet-4-20250514)
- **Database**: Supabase (PostgreSQL)
- **Messaging**: WhatsApp Business Cloud API (Meta)
- **Payments**: Razorpay (India) + Stripe (International)
- **Hosting**: Railway
- **Admin Dashboard**: React (single HTML file with CDN dependencies)

## Project Structure
```
├── app/
│   ├── main.py              # FastAPI entry point
│   ├── config/
│   │   └── settings.py      # Environment variables & config
│   ├── routes/
│   │   ├── webhook.py       # WhatsApp webhook handler
│   │   ├── admin.py         # Admin API endpoints
│   │   └── payments.py      # Payment webhook handlers
│   ├── services/
│   │   ├── whatsapp.py      # WhatsApp Cloud API client
│   │   ├── ai_agent.py      # Claude AI conversation agent
│   │   ├── database.py      # Supabase database operations
│   │   ├── payment.py       # Razorpay/Stripe integration
│   │   └── scheduler.py     # Session scheduling logic
│   ├── models/
│   │   └── schemas.py       # Pydantic models
│   └── templates/
│       └── messages.py      # WhatsApp message templates
├── admin-dashboard/
│   └── index.html           # Full admin dashboard (single file)
├── scripts/
│   └── seed_therapists.py   # Seed therapist data
├── requirements.txt
├── Procfile                  # Railway deployment
├── railway.toml              # Railway config
├── .env.example              # Environment variable template
└── CLAUDE.md                 # This file
```

## Key Conventions
- All environment variables loaded via pydantic Settings
- WhatsApp webhook verification uses GET, message handling uses POST
- AI agent returns both a client message AND a structured action
- All conversations are logged to the `conversations` table
- Admin dashboard connects directly to Supabase with realtime subscriptions
